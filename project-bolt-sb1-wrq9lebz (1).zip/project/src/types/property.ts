export interface Broker {
  name: string;
  email: string;
  phone: string;
}

export interface Property {
  id: string;
  title: string;
  address: string;
  rent: string;
  status: 'Available' | 'Pending' | 'Leased';
  description?: string;
  imageSrc?: string;
  broker: Broker;
  emailSent: boolean;
}