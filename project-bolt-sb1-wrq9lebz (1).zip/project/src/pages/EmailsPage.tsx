import React, { useState, useEffect } from 'react';
import { Filter, Mail } from 'lucide-react';
import EmailLogItem from '../components/EmailLog/EmailLogItem';
import LoadingSpinner from '../components/common/LoadingSpinner';
import { EmailLog } from '../types/email';
import { mockEmailLogs } from '../data/mockData';
import './EmailsPage.css';

const EmailsPage: React.FC = () => {
  const [emailLogs, setEmailLogs] = useState<EmailLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'sent' | 'failed' | 'pending'>('all');

  useEffect(() => {
    // Simulate loading email logs
    const timer = setTimeout(() => {
      setEmailLogs(mockEmailLogs);
      setLoading(false);
    }, 1000);
    
    return () => clearTimeout(timer);
  }, []);

  const handleResendEmail = (emailId: string) => {
    // Simulate resending email
    setEmailLogs(prevLogs => 
      prevLogs.map(log => 
        log.id === emailId 
          ? { ...log, status: 'pending', timestamp: new Date().toISOString() } 
          : log
      )
    );
    
    // Simulate email being sent after a delay
    setTimeout(() => {
      setEmailLogs(prevLogs => 
        prevLogs.map(log => 
          log.id === emailId 
            ? { ...log, status: 'sent', timestamp: new Date().toISOString() } 
            : log
        )
      );
    }, 2000);
  };

  const filteredLogs = emailLogs.filter(log => 
    filter === 'all' || log.status === filter
  );

  return (
    <div className="container emails-page">
      <div className="emails-header">
        <div className="emails-title">
          <Mail size={24} />
          <h1>Email Logs</h1>
        </div>
        <p className="emails-subheader">
          Track all communications with property brokers
        </p>
      </div>
      
      <div className="emails-filters">
        <button 
          className={`filter-button ${filter === 'all' ? 'active' : ''}`}
          onClick={() => setFilter('all')}
        >
          All
        </button>
        <button 
          className={`filter-button ${filter === 'sent' ? 'active' : ''}`}
          onClick={() => setFilter('sent')}
        >
          Sent
        </button>
        <button 
          className={`filter-button ${filter === 'pending' ? 'active' : ''}`}
          onClick={() => setFilter('pending')}
        >
          Pending
        </button>
        <button 
          className={`filter-button ${filter === 'failed' ? 'active' : ''}`}
          onClick={() => setFilter('failed')}
        >
          Failed
        </button>
      </div>
      
      {loading ? (
        <div className="loading-container">
          <LoadingSpinner size="large" />
          <p>Loading email logs...</p>
        </div>
      ) : filteredLogs.length > 0 ? (
        <div className="email-logs-list">
          {filteredLogs.map(log => (
            <EmailLogItem 
              key={log.id} 
              log={log} 
              onResend={handleResendEmail}
            />
          ))}
        </div>
      ) : (
        <div className="no-emails">
          <Filter size={48} className="no-emails-icon" />
          <p>No emails found matching the selected filter.</p>
          {filter !== 'all' && (
            <button 
              className="button"
              onClick={() => setFilter('all')}
            >
              Show All Emails
            </button>
          )}
        </div>
      )}
    </div>
  );
};

export default EmailsPage;