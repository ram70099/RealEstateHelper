import React, { useState, useEffect } from 'react';
import { Search } from 'lucide-react';
import PropertyCard from '../components/PropertyCard/PropertyCard';
import LoadingSpinner from '../components/common/LoadingSpinner';
import { Property } from '../types/property';
import { mockProperties } from '../data/mockData';
import './PropertiesPage.css';

const PropertiesPage: React.FC = () => {
  const [properties, setProperties] = useState<Property[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filter, setFilter] = useState<string>('all');

  useEffect(() => {
    // Simulate loading properties
    const timer = setTimeout(() => {
      setProperties(mockProperties);
      setLoading(false);
    }, 1000);
    
    return () => clearTimeout(timer);
  }, []);

  const handleSendEmail = (propertyId: string) => {
    setProperties(prevProperties => 
      prevProperties.map(property => 
        property.id === propertyId 
          ? { ...property, emailSent: true } 
          : property
      )
    );
  };

  const filteredProperties = properties.filter(property => {
    const matchesSearch = 
      property.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      property.address.toLowerCase().includes(searchTerm.toLowerCase()) ||
      property.broker.name.toLowerCase().includes(searchTerm.toLowerCase());
      
    const matchesFilter = 
      filter === 'all' || 
      property.status.toLowerCase() === filter.toLowerCase();
      
    return matchesSearch && matchesFilter;
  });

  return (
    <div className="container properties-page">
      <div className="properties-header">
        <h1>Available Properties</h1>
        <p className="properties-subheader">
          {properties.length} properties found from your uploaded documents
        </p>
      </div>
      
      <div className="properties-controls">
        <div className="search-container">
          <Search size={18} className="search-icon" />
          <input
            type="text"
            placeholder="Search properties, addresses, or brokers..."
            className="search-input"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        
        <div className="filter-container">
          <select 
            className="filter-select"
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
          >
            <option value="all">All Status</option>
            <option value="available">Available</option>
            <option value="pending">Pending</option>
            <option value="leased">Leased</option>
          </select>
        </div>
      </div>
      
      {loading ? (
        <div className="loading-container">
          <LoadingSpinner size="large" />
          <p>Loading properties...</p>
        </div>
      ) : filteredProperties.length > 0 ? (
        <div className="properties-grid">
          {filteredProperties.map(property => (
            <PropertyCard 
              key={property.id} 
              property={property} 
              onSendEmail={handleSendEmail}
            />
          ))}
        </div>
      ) : (
        <div className="no-properties">
          <p>No properties found matching your criteria.</p>
        </div>
      )}
    </div>
  );
};

export default PropertiesPage;